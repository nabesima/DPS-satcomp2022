#ifndef _propdense_h_INCLUDED
#define _propdense_h_INCLUDED

struct kissat;

#include <limits.h>

bool kissat_dense_propagate (struct kissat *);

#endif
